To learn more about the font family and its license, visit https://www.fontmirror.com/garet

License: Free for personal use.
This is a preview font for testing, you can purchase its full version at https://www.myfonts.com/fonts/spacetype/garet/.